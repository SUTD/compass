#ifndef ABDUCTOR_H_
#define ABDUCTOR_H_

//namespace Abductor {

//class ProofObligation;




//}

#endif /* ABDUCTOR_H_ */
