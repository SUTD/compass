void foo(int x, int y)
{

  char* a = "compass";
  char* b = "sail";
  static_assert(a==b);
}