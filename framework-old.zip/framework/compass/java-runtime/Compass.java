package verify;

public class Compass
{

  public static void static_assert(boolean b)
  {

  }
  
  public static void taint_drf(Object o)
  {

  }
  
  public static void leak(Object o)
  {

  }
  
  public static void leak_all(Object o)
  {

  }


}