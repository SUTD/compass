/*
 * AnalysisResult.cpp
 *
 *  Created on: Nov 23, 2009
 *      Author: tdillig
 */

#include "AnalysisResult.h"

AnalysisResult::AnalysisResult()
{
	time = 0;
	termination_value = 0;

}

AnalysisResult::~AnalysisResult()
{

}
