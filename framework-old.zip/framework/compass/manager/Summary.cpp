/*
 * Summary.cpp
 *
 *  Created on: Aug 15, 2008
 *      Author: tdillig
 */

#include "Summary.h"

Summary::Summary() {
	// TODO Auto-generated constructor stub

}



Summary::~Summary() {
	// TODO Auto-generated destructor stub
}


bool Summary::is_externally_managed()
{
	return false;
}
